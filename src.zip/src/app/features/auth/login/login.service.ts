import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {LocalStorageService, SessionStorageService} from "ngx-webstorage";
import {AuthServerProvider} from "@app/features/auth/access/auth-jwt.service";
import {AccountService} from "@app/features/auth/access/account.service";

@Injectable(({ providedIn: 'root' }))
export class loginService{



    constructor(private http: HttpClient,private authServerProvider: AuthServerProvider, private accountService: AccountService) {


    }


    // attemptAuth(username: string, password: string): Observable<any>{
    //   const  credentials = {username: username, password: password};
    //     console.log('attempAuth ::');
    //     return this.http.post('/api/api/authenticate', credentials);
    //
    // }



    login(credentials, callback?) {
        const cb = callback || function() {};

        return new Promise((resolve, reject) => {
            this.authServerProvider.login(credentials).subscribe(
                data => {
                    this.accountService.identity(true).then(account => {
                        resolve(data);
                    });
                    return cb();
                },
                err => {
                    this.logout();
                    reject(err);
                    return cb(err);
                }
            );
        });
    }


    loginWithToken(jwt, rememberMe) {
        return this.authServerProvider.loginWithToken(jwt, rememberMe);
    }

    logout() {
        this.authServerProvider.logout().subscribe();
        this.accountService.authenticate(null);
    }


    getloginuser(){
        return   this.http.get('/api/api/authenticate');
    }


}