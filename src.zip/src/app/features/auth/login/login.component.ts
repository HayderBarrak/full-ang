import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {Observable} from "rxjs";
import {HttpClient} from "@angular/common/http";
import {TokenStorage} from "@app/features/auth/login/token.storage";
import {loginService} from "@app/features/auth/login/login.service";
import {LocalStorageService, SessionStorageService} from "ngx-webstorage";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {StateStorageService} from "@app/features/auth/access/state-storage.service";




@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  providers: [loginService]
})
export class LoginComponent implements OnInit {
    authenticationError: boolean;
    password: string;
    rememberMe: boolean;
    username: string;
    credentials: any;

  constructor(private stateStorageService: StateStorageService,private router: Router,private http: HttpClient,private token: TokenStorage,private loginservice:loginService,  public activeModal: NgbActiveModal) { }

  ngOnInit() {
   //   this.getuser();

  }




  // login() {
  //   this.loginservice.attemptAuth(this.username, this.password).subscribe(
  //       data => {
  //         this.token.saveToken(data.token);
  //        console.log("works");
  //        this.router.navigate(['home'])
  //       }
  //   );
  // }

    login() {
        this.loginservice
            .login({
                username: this.username,
                password: this.password,
                rememberMe: this.rememberMe
            })
            .then(() => {
                this.authenticationError = false;
                this.activeModal.dismiss('login success');
                if (this.router.url === '/register' || /^\/activate\//.test(this.router.url) || /^\/reset\//.test(this.router.url)) {
                    this.router.navigate(['']);
                }


                // previousState was set in the authExpiredInterceptor before being redirected to login modal.
                // since login is successful, go to stored previousState and clear previousState
                const redirect = this.stateStorageService.getUrl();
                if (redirect) {
                    this.stateStorageService.storeUrl(null);
                    this.router.navigate([redirect]);
                }
            })
            .catch(() => {
                this.authenticationError = true;
            });
        this.router.navigate(['home'])
    }


    getuser(){
      this.loginservice.getloginuser();
    }





   // login(event){
    // event.preventDefault();
    //



}
