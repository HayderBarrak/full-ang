import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sa-topic-view',
  templateUrl: './topic-view.component.html',
})
export class TopicViewComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
