import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs";
import {HttpClient, HttpResponse} from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import {User} from "@app/shared/user/User.model";
import {UserService} from "@app/shared/user/user.service";
import {AccountService} from "@app/features/auth/access/account.service";


@Component({
  selector: 'datatables-rest-demo',
  templateUrl: './datatables-rest-demo.component.html',
  styles: [],
})
export class DatatablesRestDemoComponent implements OnInit {

  // public REST_ROOT = 'https://jsonplaceholder.typicode.com';
  //
  // options = {
  //   dom: "Bfrtip",
  //   ajax: (data, callback, settings) => {
  //     this.http.get(this.REST_ROOT + '/posts')
  //       .pipe(
  //         map((data: any)=>(data.data || data)),
  //         catchError(this.handleError),
  //       )
  //       .subscribe((data) => {
  //         console.log('data from rest endpoint', data);
  //         callback({
  //           aaData: data.slice(0, 100)
  //         })
  //       })
  //   },
  //   columns: [
  //     { data: "userId" },
  //     { data: "id" },
  //     { data: "title" },
  //     { data: "body" },
  //   ]
  // };

  currentAccount: any;
  users: User[];
  error: any;
  success: any;
  routeData: any;
  links: any;
  totalItems: any;
  queryCount: any;
  itemsPerPage: any;
  page: any;
  predicate: any;
  previousPage: any;
  reverse: any;

  constructor(private http: HttpClient,private userService: UserService, private accountService: AccountService) { }

  ngOnInit() {
this.accountService.identity().then(account =>{

  this.loadAll();
});

  }


  loadAll() {
    this.userService
        .query({// sort: this.sort()
        })
        .subscribe(
            (res: HttpResponse<User[]>) => console.log("it works")
        );
  }
  trackIdentity(index, item: User) {
    return item.id;
  }


  isAuthenticated() {
    return this.accountService.isAuthenticated();
  }
  // private handleError(error: any) {
  //   // In a real world app, we might use a remote logging infrastructure
  //   // We'd also dig deeper into the error to get a better message
  //   let errMsg = (error.message) ? error.message :
  //     error.status ? `${error.status} - ${error.statusText}` : 'Server error';
  //   console.error(errMsg); // log to console instead
  //   return Observable.throw(errMsg);
  // }

}
