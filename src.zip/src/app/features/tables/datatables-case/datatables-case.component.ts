import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sa-datatables-case',
  templateUrl: './datatables-case.component.html',
})
export class DatatablesCaseComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
