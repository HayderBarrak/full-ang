import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sa-app-layouts',
  templateUrl: './app-layouts.component.html',
})
export class AppLayoutsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
