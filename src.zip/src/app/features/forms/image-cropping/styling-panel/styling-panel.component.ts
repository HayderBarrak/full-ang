import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'image-editor-styling-panel',
  templateUrl: './styling-panel.component.html',
  styles: []
})
export class StylingPanelComponent implements OnInit {

  public storeId = 'stylingPanel'

  constructor() { }

  ngOnInit() {
  }

}
