import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'image-editor-show-selection-panel',
  templateUrl: './show-selection-panel.component.html',
})
export class ShowSelectionPanelComponent implements OnInit {

  public storeId = 'showSelectionPanel';

  constructor() { }

  ngOnInit() {
  }

}
